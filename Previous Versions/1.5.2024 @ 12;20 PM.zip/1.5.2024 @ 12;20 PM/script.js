document.addEventListener("DOMContentLoaded", (event) => {
    // Script To Load Automatically Once Website Loads
});
