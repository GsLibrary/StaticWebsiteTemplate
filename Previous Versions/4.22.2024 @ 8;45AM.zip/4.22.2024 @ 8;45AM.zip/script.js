document.addEventListener("DOMContentLoaded", (event) => {
    console.log("Website Has Been Loaded");
});
